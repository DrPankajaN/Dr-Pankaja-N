import React from "react";
import ReactDOM from "react-dom";

import App from "./components/App";

ReactDOM.render(
  <div>
    <App />
    <h1> hello</h1>
  </div>,
  document.getElementById("root")
);
