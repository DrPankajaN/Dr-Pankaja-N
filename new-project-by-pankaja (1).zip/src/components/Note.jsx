import React from "react";

function Note() {
  return (
    /* <header> <h1> ShapeAI</h1> </header>);   */

    <div className="note">
      <h1 align="center "> Javascrip and React.jst</h1>

      <p>
        {" "}
        This was an amazing bootcamp taken by shurya sir he covered everything
        form scractch including react.js,HTML. CSS{" "}
      </p>
    </div>
  );
}

export default Note;
