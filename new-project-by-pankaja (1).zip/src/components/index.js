import React from "react";
import ReactDOM from "react-dom";

/*import App from "./components/App";*/

ReactDOM.render(
  <div>
    <h1> hello</h1>
  </div>,

  document.getElementById("root")
);
