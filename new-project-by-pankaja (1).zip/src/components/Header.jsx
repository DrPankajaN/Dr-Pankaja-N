import React from "react";

function Header() {
  return (
    <header align="center">
      <h1> ShapeAI </h1>
    </header>
  );
}

export default Header;
