import React from "react";

function Footer() {
  return (
    <footer align="center">
      <h1> Copyright @ ShapeAI </h1>
    </footer>
  );
}

export default Footer;
